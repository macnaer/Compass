import React from "react";
import UserInformation from "../../components/userInformation";

const DefaultPage: React.FC = () => {
  return <UserInformation />;
};

export default DefaultPage;
