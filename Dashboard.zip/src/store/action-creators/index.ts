import * as UserActionCreators from "./userActions";

export default{
    ...UserActionCreators
}